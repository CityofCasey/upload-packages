/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'tt', {
	IdInputLabel: 'Идентификатор',
	advisoryTitleInputLabel: 'Киңәш исем',
	cssClassInputLabel: 'Стильләр класслары',
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Эчке стиль',
	langDirLTRLabel: 'Сулдан уңга язылыш (LTR)',
	langDirLabel: 'Язылыш юнəлеше',
	langDirRTLLabel: 'Уңнан сулга язылыш (RTL)',
	languageCodeInputLabel: 'Тел коды',
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'Стиль',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
} );
